def sumEggs(a,b):
  return a + b

